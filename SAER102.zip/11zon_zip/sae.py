
__all__ =['cree_reseau','liste_personnes','sont_amis','sont_amis_de','est_comu','comu','tri_popu','comu_dans_reseau',
          'comu_dans_amis','comu_max']


#Question1

def cree_reseau(couples):
    reseau = {}
    for a, b in couples:
        if a not in reseau:
            reseau[a] = []
        if b not in reseau:
            reseau[b] = []
        if b not in reseau[a]:
            reseau[a].append(b)
        if a not in reseau[b]:
            reseau[b].append(a)
    return reseau
    
    
#Question3

def liste_personnes(reseau):
    personnes = []
    for personne in reseau:
        personnes.append(personne)
    return personnes


#Question4

def sont_amis(reseau, personne1, personne2):
    if personne1 in reseau:  # Vérifie si `personne1` est dans le réseau
        for ami in reseau[personne1]:  # Parcourt les amis de `personne1`
            if ami == personne2:  # Si `personne2` est trouvé
                return True
    return False  # Si aucune correspondance n'est trouvée

#Question5

def sont_amis_de(reseau, personne):
    if personne in reseau:
        return reseau[personne]
    return []
#Question6

def est_comu(reseau, groupe):
    for personne in groupe:  # Pour chaque personne dans le groupe
        for autre in groupe:  # Compare avec toutes les autres personnes
            if personne != autre:  # Si ce n'est pas la même personne
                if personne in reseau and autre in reseau[personne]:  # Si elles sont amies
                    continue
                else:  # Si elles ne sont pas amies
                    return False
    return True  # Si toutes les comparaisons réussissent

#Question7

def comu(reseau, groupe):
    communaute = []
    for personne in groupe:  # Pour chaque personne dans le groupe
        compatible = True
        for membre in communaute:  # Vérifie avec tous les membres de la communauté
            if membre in reseau and personne in reseau[membre]:
                continue
            else:
                compatible = False
        if compatible:  # Si la personne est compatible avec la communauté
            communaute.append(personne)
    return communaute
#Question8
def tri_popu(reseau, groupe):
    for i in range(len(groupe)):
        for j in range(i + 1, len(groupe)):
            if len(reseau[groupe[j]]) > len(reseau[groupe[i]]):  # Compare les nombres d'amis
                temp = groupe[i]  # Échange les positions
                groupe[i] = groupe[j]
                groupe[j] = temp
    return groupe

#Question9

def comu_dans_reseau(reseau):
    groupe = liste_personnes(reseau)  # Récupère toutes les personnes
    groupe = tri_popu(reseau, groupe)  # Trie par popularité
    return comu(reseau, groupe)  # Retourne la communauté
    
#Question10

def comu_dans_amis(reseau, personne):
    communaute = [personne]  # On commence avec la personne initiale
    for ami in reseau[personne]:  # Parcourt les amis de cette personne
        compatible = True
        for membre in communaute:  # Vérifie si cet ami est compatible avec la communauté actuelle
            if membre in reseau and ami in reseau[membre]:
                continue
            else:
                compatible = False
        if compatible:  # Si l'ami est compatible, on l'ajoute
            communaute.append(ami)
    return communaute

#Question12

def comu_max(reseau):
    max_communaute = []
    personnes = liste_personnes(reseau)  # Liste de toutes les personnes
    for personne in personnes:  # Pour chaque personne dans le réseau
        communaute = comu(reseau, [personne] + reseau[personne])  # Construit une communauté
        if len(communaute) > len(max_communaute):  # Si cette communauté est plus grande
            max_communaute = communaute  # La remplace
    return max_communaute

