from sae.py import *

#exemple de reseau que nous allons utiliser pour les tests
reseau = {
    "Alice": ["Bob", "Dan"],
    "Bob": ["Alice", "Carl", "Dan"],
    "Carl": ["Bob"],
    "Dan": ["Alice", "Bob"]
}

couples = [("Alice", "Bob"), ("Alice", "Dan"), ("Bob", "Carl"), ("Bob", "Dan")]
groupe = ["Alice", "Bob", "Dan"]


def test_cree_reseau():
    resultat = cree_reseau(couples)
    attendu = {
        "Alice": ["Bob", "Dan"],
        "Bob": ["Alice", "Carl", "Dan"],
        "Carl": ["Bob"],
        "Dan": ["Alice", "Bob"]
    }
    assert resultat == attendu
    print("Test cree_reseau : OK")

def test_liste_personnes():
    resultat = liste_personnes(reseau)
    attendu = ["Alice", "Bob", "Carl", "Dan"]
    assert sorted(resultat) == sorted(attendu) #on les trie pour qu'elle soit identique si ce sont les memes noms
    print("Test liste_personnes : OK")

def test_sont_amis():
    assert sont_amis(reseau, "Alice", "Bob") == True
    assert sont_amis(reseau, "Alice", "Carl") == False
    print("Test sont_amis : OK")
    
def test_sont_amis_de():
    resultat = sont_amis_de(reseau, "Alice")
    attendu = ["Bob", "Dan"]
    assert sorted(resultat) == sorted(attendu) #idem que pour le dessus
    resultat = sont_amis_de(reseau, "Carl")
    attendu = ["Bob"]
    assert resultat == attendu
    print("Test sont_amis_de : OK")

def test_est_comu():
    assert est_comu(reseau, ["Alice", "Bob", "Dan"]) == True
    assert est_comu(reseau, ["Alice", "Bob", "Carl"]) == False
    print("Test est_comu : OK")

def test_comu():
    resultat = comu(reseau, ["Alice", "Bob", "Dan", "Carl"])
    attendu = ["Alice", "Bob", "Dan"]
    assert sorted(resultat) == sorted(attendu)
    print("Test comu : OK")

def test_tri_popu():
    resultat = tri_popu(reseau, ["Alice", "Bob", "Carl", "Dan"])
    attendu = ["Bob", "Alice", "Dan", "Carl"]
    assert resultat == attendu
    print("Test tri_popu : OK")
    
def test_comu_dans_reseau():
    resultat = comu_dans_reseau(reseau)
    attendu = ["Alice", "Bob", "Dan"]
    assert sorted(resultat) == sorted(attendu)
    print("Test comu_dans_reseau : OK")

def test_comu_dans_amis():
    resultat = comu_dans_amis(reseau, "Alice")
    attendu = ["Alice", "Bob", "Dan"]
    assert sorted(resultat) == sorted(attendu)
    print("Test comu_dans_amis : OK")

def test_comu_max():
    resultat = comu_max(reseau)
    attendu = ["Alice", "Bob", "Dan"]
    assert sorted(resultat) == sorted(attendu)
    print("Test comu_max : OK")
    
 
def test_finale():
   test_cree_reseau()
   test_liste_personnes()
   test_sont_amis()
   test_sont_amis_de()       
   test_est_comu()
   test_comu()
   test_tri_popu()
   test_comu_dans_reseau()
   test_comu_dans_amis()
   test_comu_max()
   print("Tous les tests sont passés avec succès.")
